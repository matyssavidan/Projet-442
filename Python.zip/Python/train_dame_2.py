import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
import copy

BOARD_SIZE = 10
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class DamesNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(BOARD_SIZE * BOARD_SIZE * 5, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, BOARD_SIZE * BOARD_SIZE * BOARD_SIZE * BOARD_SIZE)
        )

    def forward(self, x):
        return self.fc(x)

def encode_state(plateau):
    onehot = np.zeros((5, BOARD_SIZE, BOARD_SIZE), dtype=np.float32)
    for r in range(BOARD_SIZE):
        for c in range(BOARD_SIZE):
            v = plateau[r][c]
            if 1 <= v <= 4:
                onehot[v - 1][r][c] = 1.0
            else:
                onehot[4][r][c] = 1.0
    return torch.tensor(onehot.flatten(), dtype=torch.float32).to(DEVICE).detach()

def print_board(board):
    symbols = {0: '.', 1: 'b', 2: 'n', 3: 'B', 4: 'N'}
    print("   " + " ".join(str(c) for c in range(10)))
    for r in range(10):
        row = " ".join(symbols[board[r][c]] for c in range(10))
        print(f"{r}  {row}")

class DamesEnv:
    def __init__(self):
        self.reset()

    def reset(self):
        self.board = np.zeros((10, 10), dtype=np.int8)
        for r in range(4):
            for c in range((r+1)%2, 10, 2):
                self.board[r][c] = 2
        for r in range(6, 10):
            for c in range((r+1)%2, 10, 2):
                self.board[r][c] = 1
        self.current_player = 1
        return self.board.copy()

    def legal_moves(self, board, player):
        moves = []
        captures = []  # Séparation entre les coups normaux et les captures
        for r in range(10):
            for c in range(10):
                piece = board[r][c]
                if piece in ([1, 3] if player == 1 else [2, 4]):
                    is_dame = piece in [3, 4]
                    if not is_dame:
                        directions = [(-1, -1), (-1, 1)] if piece == 1 else [(1, -1), (1, 1)]
                        for dr, dc in directions:
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < 10 and 0 <= nc < 10 and board[nr][nc] == 0:
                                moves.append(((r, c), (nr, nc)))
                            nr2, nc2 = r + 2*dr, c + 2*dc
                            if 0 <= nr2 < 10 and 0 <= nc2 < 10 and board[nr2][nc2] == 0:
                                mid_r, mid_c = r + dr, c + dc
                                if board[mid_r][mid_c] in ([2, 4] if player == 1 else [1, 3]):
                                    captures.append(((r, c), (nr2, nc2)))
                    else:
                        for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                            i = 1
                            while True:
                                nr, nc = r + i*dr, c + i*dc
                                if not (0 <= nr < 10 and 0 <= nc < 10):
                                    break
                                if board[nr][nc] == 0:
                                    moves.append(((r, c), (nr, nc)))
                                    i += 1
                                else:
                                    # tentative de capture
                                    if board[nr][nc] in ([2, 4] if player == 1 else [1, 3]):
                                        j = 1
                                        while True:
                                            nr2, nc2 = nr + j*dr, nc + j*dc
                                            if not (0 <= nr2 < 10 and 0 <= nc2 < 10):
                                                break
                                            if board[nr2][nc2] != 0:
                                                break
                                            captures.append(((r, c), (nr2, nc2)))
                                            j += 1
                                    break
        # Retourner prioritairement les captures si elles existent
        return captures if captures else moves

    def get_captures_from_position(self, board, r, c, player, piece):
        """Récupère toutes les captures possibles depuis une position spécifique"""
        captures = []
        is_dame = piece in [3, 4]
        
        if not is_dame:
            # Pour les pions, recherche dans toutes les directions (pas juste avant)
            for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                nr2, nc2 = r + 2*dr, c + 2*dc
                if 0 <= nr2 < 10 and 0 <= nc2 < 10 and board[nr2][nc2] == 0:
                    mid_r, mid_c = r + dr, c + dc
                    if board[mid_r][mid_c] in ([2, 4] if player == 1 else [1, 3]):
                        captures.append(((r, c), (nr2, nc2)))
        else:
            # Pour les dames
            for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                i = 1
                while True:
                    nr, nc = r + i*dr, c + i*dc
                    if not (0 <= nr < 10 and 0 <= nc < 10):
                        break
                    if board[nr][nc] != 0:
                        # Tentative de capture
                        if board[nr][nc] in ([2, 4] if player == 1 else [1, 3]):
                            j = 1
                            while True:
                                nr2, nc2 = nr + j*dr, nc + j*dc
                                if not (0 <= nr2 < 10 and 0 <= nc2 < 10):
                                    break
                                if board[nr2][nc2] != 0:
                                    break
                                captures.append(((r, c), (nr2, nc2)))
                                j += 1
                        break
                    i += 1
        
        return captures
        
    def step(self, action):
        (r0, c0), (r1, c1) = action
        reward = 0
        done = False
        continue_capture = False

        if self.board[r0][c0] == 0:
            return self.board.copy(), -5, False, continue_capture

        player = self.current_player
        piece = self.board[r0][c0]

        #  Compter les pièces du joueur avant le coup
        pre_count = np.sum((self.board == piece) | 
                        (self.board == (3 if piece == 1 else 4)))

        is_capture = abs(r1 - r0) >= 2 or abs(c1 - c0) >= 2

        if is_capture:
            dr = (r1 - r0) // max(1, abs(r1 - r0))
            dc = (c1 - c0) // max(1, abs(c1 - c0))
            r, c = r0 + dr, c0 + dc
            captured = False
            
            while (r != r1 or c != c1) and 0 <= r < 10 and 0 <= c < 10:
                if self.board[r][c] in ([2, 4] if player == 1 else [1, 3]):
                    self.board[r][c] = 0
                    captured = True
                    reward += 5
                    break
                r += dr
                c += dc
            
            if not captured:
                reward -= 5
        else:
            captures_available = [
                m for m in self.legal_moves(self.board, player)
                if abs(m[0][0] - m[1][0]) >= 2
            ]
            if captures_available:
                reward -= 10
            else:
                reward -= 0.1

        # Déplacer la pièce
        self.board[r1][c1] = piece
        self.board[r0][c0] = 0

        #  Compter les pièces du joueur après le coup
        post_count = np.sum((self.board == piece) | 
                            (self.board == (3 if piece == 1 else 4)))
        
        if post_count < pre_count:
            reward -= 3  # pénalité pour avoir perdu une pièce

        # Vérifier capture en chaîne
        if is_capture:
            temp_board = self.board.copy()
            further_captures = self.get_captures_from_position(temp_board, r1, c1, player, piece)
            if further_captures:
                continue_capture = True
                reward += 3
            else:
                self.current_player = 3 - player
        else:
            self.current_player = 3 - player

        # Promotion en dame
        if player == 1 and r1 == 0 and piece == 1:
            self.board[r1][c1] = 3
            reward += 2
        elif player == 2 and r1 == 9 and piece == 2:
            self.board[r1][c1] = 4
            reward += 2

        # Vérifier fin de partie
        if not continue_capture and not self.legal_moves(self.board, self.current_player):
            done = True
            reward += 10

        return self.board.copy(), reward, done, continue_capture


class DQNAgent:
    def __init__(self, is_training=True):
        self.model = DamesNet().to(DEVICE)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        self.loss_fn = nn.MSELoss()
        self.gamma = 0.95
        self.epsilon = 1.0 
        self.memory = []
        self.is_training = is_training  # Indique si cet agent doit être entraîné

    def select_action(self, state, legal_moves):
        if random.random() < self.epsilon:
            return random.choice(legal_moves)
        
        with torch.no_grad():
            x = encode_state(state).unsqueeze(0)
            qvals = self.model(x).cpu().numpy()[0]
        
        best_move = max(legal_moves, key=lambda m: qvals[self.encode_action_index(m)])
        return best_move

    def encode_action_index(self, move):
        (r0, c0), (r1, c1) = move
        return r0 * 1000 + c0 * 100 + r1 * 10 + c1

    def remember(self, s, a, r, s2, done):
        if self.is_training:
            self.memory.append((s, a, r, s2, done))
            if len(self.memory) > 10000:
                self.memory.pop(0)

    def train(self, batch_size=64):
        if not self.is_training or len(self.memory) < batch_size:
            return 0
        
        batch = random.sample(self.memory, batch_size)
        states, targets = [], []
        
        for s, a, r, s2, done in batch:
            x = encode_state(s)
            y = self.model(x.unsqueeze(0)).detach().squeeze().clone()
            idx = self.encode_action_index(a)
            
            if done:
                y[idx] = r
            else:
                q_next = self.model(encode_state(s2).unsqueeze(0)).max().item()
                y[idx] = r + self.gamma * q_next
            
            states.append(x)
            targets.append(y)
        
        xs = torch.stack(states)
        ys = torch.stack(targets)
        pred = self.model(xs)
        loss = self.loss_fn(pred, ys)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return loss.item()

def train_loop(episodes=50, alternate_every=5):
    env = DamesEnv()
    
    # Créer deux agents
    agent1 = DQNAgent(is_training=True)   # Agent pour le joueur 1 (blanc)
    agent2 = DQNAgent(is_training=False)  # Agent pour le joueur 2 (noir)
    
    metrics = {
        "episode_rewards": [],
        "episode_lengths": [],
        "agent1_losses": [],
        "agent2_losses": []
    }
    
    for ep in range(episodes):
        #  Alternance correcte tous les `alternate_every` épisodes
        if (ep // alternate_every) % 2 == 0:
            agent1.is_training = True
            agent2.is_training = False
        else:
            agent1.is_training = False
            agent2.is_training = True

        # 🔧 Réinitialiser epsilon correctement selon le statut d'entraînement
        if agent1.is_training and agent1.epsilon == 0.1:
            agent1.epsilon = 1.0
        if agent2.is_training and agent2.epsilon == 0.1:
            agent2.epsilon = 1.0

        print(f"\n Épisode {ep+1} : Agent1 training = {agent1.is_training}, Agent2 training = {agent2.is_training}")

        s = env.reset()
        total_reward = 0
        done = False
        step_count = 0
        MAX_STEPS = 200
        
        while not done and step_count < MAX_STEPS:
            player = env.current_player
            agent = agent1 if player == 1 else agent2
            
            legal = env.legal_moves(s, player)
            if not legal:
                break
                
            a = agent.select_action(s, legal)
            s2, r, done, continue_capture = env.step(a)
            
            # Captures multiples (rafles)
            current_state = s2
            total_r = r
            while continue_capture:
                new_r0, new_c0 = a[1]
                captures = env.get_captures_from_position(current_state, new_r0, new_c0, player, current_state[new_r0][new_c0])
                if not captures:
                    break
                next_capture = agent.select_action(current_state, captures)
                print(f"Prise multiple: {next_capture}") if ep % 10 == 0 or ep == episodes - 1 else None
                next_s, next_r, done, continue_capture = env.step(next_capture)
                current_state = next_s
                total_r += next_r
                a = next_capture

            agent.remember(s, a, total_r, current_state, done)
            loss = agent.train()
            
            if agent.is_training:
                metrics_key = "agent1_losses" if player == 1 else "agent2_losses"
                metrics[metrics_key].append(loss)
            
            if ep % 10 == 0 or ep == episodes - 1:
                print(f"\n Joueur {player} joue : {a}")
                print_board(current_state)
            
            s = current_state
            total_reward += total_r
            step_count += 1
        
        # Réduction epsilon pour l'agent actif uniquement
        if agent1.is_training:
            agent1.epsilon = max(agent1.epsilon * 0.995, 0.1)
        if agent2.is_training:
            agent2.epsilon = max(agent2.epsilon * 0.995, 0.1)
        
        metrics["episode_rewards"].append(total_reward)
        metrics["episode_lengths"].append(step_count)
        
        print(f" Épisode {ep+1}, Reward total = {total_reward:.2f}, "
              f"Epsilon Agent1 = {agent1.epsilon:.3f}, Epsilon Agent2 = {agent2.epsilon:.3f}")
        
        if ep % 50 == 0 or ep == episodes - 1:
            torch.save(agent1.model.state_dict(), f"dames_policy_agent1_ep{ep}.pt")
            torch.save(agent2.model.state_dict(), f"dames_policy_agent2_ep{ep}.pt")
    
    # Sauvegarde finale
    torch.save(agent1.model.state_dict(), "dames_policy_agent1.pt")
    torch.save(agent2.model.state_dict(), "dames_policy_agent2.pt")
    print(" Entraînement terminé. Poids enregistrés.")
    
    return agent1, agent2, metrics


if __name__ == "__main__":
    train_loop()