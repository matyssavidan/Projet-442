#!/usr/bin/env python3
import serial, sys, torch, numpy as np
from train_dame_2 import DamesNet, encode_state

PORT = "/dev/tty.usbmodem14103"  # ou "COM3"
BAUD = 115200

BOARD_SIZE = 10
DEVICE = torch.device("cpu")

# --- Fonctions utilitaires ---
def decode_action_index(index):
    r0 = index // 1000
    c0 = (index % 1000) // 100
    r1 = (index % 100) // 10
    c1 = index % 10
    return (r0, c0), (r1, c1)

def encode_plateau(plateau):
    return [val for row in plateau for val in row]

def decode_plateau(raw_bytes):
    return [list(raw_bytes[i*10:(i+1)*10]) for i in range(10)]

def legal_moves(board, player):
    moves = []
    captures = []
    for r in range(10):
        for c in range(10):
            piece = board[r][c]
            if piece in ([1, 3] if player == 1 else [2, 4]):
                is_dame = piece in [3, 4]
                if not is_dame:
                    directions = [(-1, -1), (-1, 1)] if piece == 1 else [(1, -1), (1, 1)]
                    for dr, dc in directions:
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < 10 and 0 <= nc < 10 and board[nr][nc] == 0:
                            moves.append(((r, c), (nr, nc)))
                        nr2, nc2 = r + 2*dr, c + 2*dc
                        if 0 <= nr2 < 10 and 0 <= nc2 < 10 and board[nr2][nc2] == 0:
                            mid_r, mid_c = r + dr, c + dc
                            if board[mid_r][mid_c] in ([2, 4] if player == 1 else [1, 3]):
                                captures.append(((r, c), (nr2, nc2)))
                else:
                    for dr, dc in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                        i = 1
                        while True:
                            nr, nc = r + i*dr, c + i*dc
                            if not (0 <= nr < 10 and 0 <= nc < 10):
                                break
                            if board[nr][nc] == 0:
                                moves.append(((r, c), (nr, nc)))
                                i += 1
                            else:
                                if board[nr][nc] in ([2, 4] if player == 1 else [1, 3]):
                                    jump_r, jump_c = nr + dr, nc + dc
                                    if 0 <= jump_r < 10 and 0 <= jump_c < 10 and board[jump_r][jump_c] == 0:
                                        captures.append(((r, c), (jump_r, jump_c)))
                                break
    return captures if captures else moves

# --- Connexion UART et chargement du modèle ---
try:
    ser = serial.Serial(PORT, BAUD, timeout=1)
    model = DamesNet().to(DEVICE)
    model.load_state_dict(torch.load("dames_policy.pt", map_location=DEVICE))
    model.eval()
    print("Modèle chargé avec succès.")
except Exception as e:
    print(f" Erreur de chargement ou de connexion série : {e}")
    sys.exit(1)

# --- Boucle principale ---
while True:
    print("Attente du plateau STM32...")
    data = ser.read(100)
    if len(data) != 100:
        print(f"Plateau incomplet : {len(data)} octets reçus")
        continue

    plateau = decode_plateau(data)
    print("Plateau reçu.")

    player = 2  # à ajuster selon le joueur que contrôle l'IA
    legal = legal_moves(plateau, player)

    if not legal:
        print(" Aucun coup légal trouvé.")
        new_bytes = encode_plateau(plateau)
    else:
        state = encode_state(plateau).unsqueeze(0)
        with torch.no_grad():
            qvals = model(state).cpu().numpy()[0]
        best_move = max(legal, key=lambda m: qvals[m[0][0]*1000 + m[0][1]*100 + m[1][0]*10 + m[1][1]])
        (r0, c0), (r1, c1) = best_move
        print(f"Coup joué : ({r0},{c0}) → ({r1},{c1})")

         # Appliquer le coup sur le plateau en tenant compte des captures
        plateau[r1][c1] = plateau[r0][c0]
        plateau[r0][c0] = 0

        # Détection et suppression du pion mangé (capture)
        dr = r1 - r0
        dc = c1 - c0
        if abs(dr) > 1 and abs(dc) > 1:
            if abs(dr) == abs(dc):
                steps = abs(dr)
                for i in range(1, steps):
                    mr = r0 + i * (dr // steps)
                    mc = c0 + i * (dc // steps)
                    if plateau[mr][mc] in ([1, 3] if player == 2 else [2, 4]):
                        plateau[mr][mc] = 0
                        break  # une seule capture à la fois dans ce jeu
                new_bytes = encode_plateau(plateau)
                
        new_bytes = encode_plateau(plateau)

    # --- Envoi case par case avec accusé 'r' ---
    print("Envoi du plateau modifié case par case...")
    for i, val in enumerate(new_bytes):
        ser.write(bytes([val]))
        ser.flush()
        ack = ser.read(1)
        if ack != b'r':
            print(f" Pas de 'r' après case {i} (val={val}) → reçu : {ack}")
            break
        else:
            print(f"Case {i:03} envoyée, accusé reçu.")
    
    print("Prêt pour le plateau suivant...\n")
