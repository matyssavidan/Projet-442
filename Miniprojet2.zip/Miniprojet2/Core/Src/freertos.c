/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications with menu, game and CPU mode
  ******************************************************************************
  */
/* USER CODE END Header */

/* -------------------------------------------------------------------------- */
/*                                  INCLUDES                                  */
/* -------------------------------------------------------------------------- */
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "main.h"
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"
#include "usart.h"               /* <-- pour huart1 */
#include <stdlib.h>
#include <time.h>
#include "main.h"

/* -------------------------------------------------------------------------- */
/*                                   DEFINES                                  */
/* -------------------------------------------------------------------------- */
#define COLS       10         // Nombre de colonnes du plateau
#define ROWS       10         // Nombre de lignes du plateau

#define P1_PAWN    1          // Pion du joueur 1 (rouge)
#define P2_PAWN    2          // Pion du joueur 2 (vert / CPU)
#define P1_KING    3          // Dame du joueur 1
#define P2_KING    4          // Dame du joueur 2

/* Boutons du menu ---------------------------------------------------------- */
#define BTN_W      210
#define BTN_H      20
#define BTN_X      ((BSP_LCD_GetXSize() - BTN_W) / 2)
#define BTN_Y      ((BSP_LCD_GetYSize() - BTN_H) / 2)
#define BTN2_Y     (BTN_Y + BTN_H + 10)

volatile uint8_t rx_from_pc;  /* dernier octet reçu */
/* -------------------------------------------------------------------------- */
/*                             VARIABLES ET HANDLES                           */
/* -------------------------------------------------------------------------- */
enum { STATE_MENU = 0, STATE_GAME } screenState = STATE_MENU; // État courant de l’écran : menu ou jeu

static uint8_t  board[ROWS][COLS]; // Plateau de jeu : tableau 10x10
static uint8_t  selected = 0;      // Une pièce est-elle sélectionnée ?
static uint16_t selR = 0, selC = 0; // Coordonnées de la pièce sélectionnée
static uint8_t  currentPlayer = 1;  // 1 = rouge, 2 = vert (ou CPU)
static uint8_t  gameOver = 0;       // Partie terminée ?
static uint8_t  winner = 0;         // Gagnant : 1 ou 2
static uint8_t  cpuMode = 0;        // 0 = PvP, 1 = contre ordinateur

volatile uint8_t caractere_recu;    // (potentiellement redondant avec rx_from_pc)


osThreadId task_displayHandle;    // Handle de la tâche d’affichage
static osThreadId task_moveHandle; // Handle de la tâche de gestion du jeu
static osMutexId  myMutex01Handle; // Mutex pour protéger les ressources partagées

/* -------------------------------------------------------------------------- */
/*                              STRUCTURES D'AIDE                             */
/* -------------------------------------------------------------------------- */
typedef struct {
  uint8_t from_r, from_c;   // Case de départ
  uint8_t to_r,   to_c;     // Case d’arrivée
  uint8_t is_capture;       // Est-ce une capture ?
} Move;                     // Représente un coup possible

/* -------------------------------------------------------------------------- */
/*                           PROTOTYPES DE FONCTIONS                          */
/* -------------------------------------------------------------------------- */
static inline uint8_t owner(uint8_t piece);  // Propriétaire d'une pièce
static inline uint8_t is_valid_move(uint16_t srcR,uint16_t srcC,
                                    uint16_t dstR,uint16_t dstC); // Coup simple valide
static inline uint8_t is_capture_move(uint16_t sR,uint16_t sC,
                                      uint16_t dR,uint16_t dC);   // Capture valide
static inline uint8_t is_valid_move_king(uint16_t sR,uint16_t sC,
                                         uint16_t dR,uint16_t dC);// Déplacement dame
static inline uint8_t is_capture_move_king(uint16_t sR,uint16_t sC,
                                           uint16_t dR,uint16_t dC);// Capture dame
static uint8_t has_additional_capture(uint16_t r,uint16_t c);// Peut-on faire une capture enchaînée ?
static void    try_promote(uint16_t r,uint16_t c);// Promotion en dame
static void    check_victory(void); // Vérification de la victoire

void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTCBBuffer,
                                   StackType_t  **ppxIdleTaskStackBuffer,
                                   uint32_t      *pulIdleTaskStackSize);

void MX_FREERTOS_Init(void); // Init générale FreeRTOS
void function_display_task(void const * argument);// Tâche d’affichage
void function_move(void const * argument);// Tâche de gestion du jeu

/* -------------------------------------------------------------------------- */
/*                MÉMOIRE STATIQUE DE L'IDLE TASK (FreeRTOS)                  */
/* -------------------------------------------------------------------------- */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t  xIdleStack[configMINIMAL_STACK_SIZE];
void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTCBBuffer,
                                   StackType_t  **ppxIdleTaskStackBuffer,
                                   uint32_t      *pulIdleTaskStackSize)
{
  *ppxIdleTCBBuffer       = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize   = configMINIMAL_STACK_SIZE;
}

/* -------------------------------------------------------------------------- */
/*                           FONCTIONS D'AIDE JEU                             */
/* -------------------------------------------------------------------------- */

static void check_victory(void)
{
    uint8_t p1 = 0, p2 = 0;
    for (uint16_t i = 0; i < ROWS; i++)
        for (uint16_t j = 0; j < COLS; j++)
        {
            if (board[i][j] == P1_PAWN || board[i][j] == P1_KING) // on compte le nombre de pièces de chaque joueurs
                p1++;
            else if (board[i][j] == P2_PAWN || board[i][j] == P2_KING)
                p2++;
        }

    if (p1 == 0) { // si le joueur 1 a 0 pièces
        gameOver = 1; winner = 2;
        screenState = STATE_MENU;
    }
    else if (p2 == 0) { // si le joueur 2 a 0 pièces
        gameOver = 1; winner = 1;
        screenState = STATE_MENU;
    }
}

static inline uint8_t owner(uint8_t piece)
{
  if(piece==P1_PAWN||piece==P1_KING) return 1; // pour savoir si la pièce est au joueur 1 ou 2 (dame ou pion)
  if(piece==P2_PAWN||piece==P2_KING) return 2;
  return 0;
}

static inline uint8_t is_valid_move(uint16_t srcR, uint16_t srcC, uint16_t dstR, uint16_t dstC)
{
  if (board[dstR][dstC] != 0) return 0;
  int dr = (int)dstR - (int)srcR;
  int dc = (int)dstC - (int)srcC;
  uint8_t piece = board[srcR][srcC];
  if (abs(dr) == 1 && abs(dc) == 1) { // mouvement en diagonale
    if (piece == P1_PAWN && dr == -1) return 1; // de une seule case
    if (piece == P2_PAWN && dr == +1) return 1;
    if (piece == P1_KING || piece == P2_KING) return 1; // du nombre de case que l'on veut
  }
  return 0;
}

static inline uint8_t is_capture_move(uint16_t sR,uint16_t sC,uint16_t dR,uint16_t dC)
{
  if(board[dR][dC]!=0) return 0;
  if(abs((int)dR-(int)sR)==2 && abs((int)dC-(int)sC)==2) // deux cases en diagnale avant ou arrière
  {
    uint16_t mR=(sR+dR)/2, mC=(sC+dC)/2;
    return (board[mR][mC]!=0 && owner(board[mR][mC])!=currentPlayer);
  }
  return 0;
}

static inline uint8_t is_valid_move_king(uint16_t sR,uint16_t sC,uint16_t dR,uint16_t dC)
{
  if(board[dR][dC]!=0) return 0;
  int dr=(dR>sR)?1:-1, dc=(dC>sC)?1:-1; // mouvement en diagonale
  if(abs((int)dR-(int)sR)==abs((int)dC-(int)sC))// d'autant de cases que l'on veut
  {
    for(uint16_t r=sR+dr,c=sC+dc; r!=dR; r+=dr,c+=dc)
      if(board[r][c]!=0) return 0; // cases déjà occupée
    return 1;
  }
  return 0;
}

static inline uint8_t is_capture_move_king(uint16_t sR,uint16_t sC,uint16_t dR,uint16_t dC)
{
  if(board[dR][dC]!=0) return 0;
  int dist=abs((int)dR-(int)sR);
  if(dist<2||dist!=abs((int)dC-(int)sC)) return 0;
  int dr=(dR>sR)?1:-1, dc=(dC>sC)?1:-1;
  uint8_t found=0;
  for(uint16_t r=sR+dr,c=sC+dc; r!=dR; r+=dr,c+=dc)
  {
    if(board[r][c]!=0)
    {
      if(found||owner(board[r][c])==currentPlayer) return 0;
      found=1;
    }
  }
  return found;
}

static uint8_t has_additional_capture(uint16_t r,uint16_t c)
{
  int dirs[4][2]={{2,2},{2,-2},{-2,2},{-2,-2}};
  for(int i=0;i<4;i++)
  {
    uint16_t nr=r+dirs[i][0], nc=c+dirs[i][1];
    if(nr<ROWS&&nc<COLS)
    {
      if((board[r][c]==P1_KING||board[r][c]==P2_KING)?is_capture_move_king(r,c,nr,nc):is_capture_move(r,c,nr,nc))
        return 1;
    }
  }
  return 0;
}

static void try_promote(uint16_t r,uint16_t c)
{
  if(board[r][c]==P1_PAWN&&r==0) board[r][c]=P1_KING;
  else if(board[r][c]==P2_PAWN&&r==ROWS-1) board[r][c]=P2_KING;
}

/* AI: pick a random move for CPU, prioritizing captures */
static Move pick_random_cpu_move(void)
{
  Move all_moves[ROWS*COLS];
  Move cap_moves[ROWS*COLS];
  int n_all=0, n_cap=0;
  for(int r=0;r<ROWS;r++){
    for(int c=0;c<COLS;c++){
      if(board[r][c]==P2_PAWN||board[r][c]==P2_KING){
        // test all destinations
        for(int dr=-ROWS; dr<=ROWS; dr++){
          for(int dc=-COLS; dc<=COLS; dc++){
            int rr=r+dr, cc=c+dc;
            if(rr<0||rr>=ROWS||cc<0||cc>=COLS) continue;
            Move m = {r,c,(uint8_t)rr,(uint8_t)cc,0};
            if(board[r][c]==P2_PAWN){
              if(is_capture_move(r,c,rr,cc)) { m.is_capture=1; cap_moves[n_cap++]=m; }
              else if(is_valid_move(r,c,rr,cc)) { m.is_capture=0; all_moves[n_all++]=m; }
            } else {
              if(is_capture_move_king(r,c,rr,cc)) { m.is_capture=1; cap_moves[n_cap++]=m; }
              else if(is_valid_move_king(r,c,rr,cc)) { m.is_capture=0; all_moves[n_all++]=m; }
            }
          }
        }
      }
    }
  }
  if(n_cap>0) return cap_moves[rand()%n_cap];
  if(n_all>0) return all_moves[rand()%n_all];
  return (Move){255,0,0,0,0}; // no move
}

/* AI: execute CPU move */
static void cpu_play_turn(void)
{
  Move m = pick_random_cpu_move();
  if(m.from_r!=255){
    uint8_t piece=board[m.from_r][m.from_c];
    board[m.to_r][m.to_c]=piece;
    board[m.from_r][m.from_c]=0;
    if(m.is_capture){
      uint16_t mr=(m.from_r+m.to_r)/2, mc=(m.from_c+m.to_c)/2;
      board[mr][mc]=0;
    }
    try_promote(m.to_r,m.to_c);
  }
  check_victory(); // Vérifier après un mouvement CPU
}

/* -------------------------------------------------------------------------- */
/*                        INITIALISATION FREERTOS                             */
/* -------------------------------------------------------------------------- */
void MX_FREERTOS_Init(void)
{
  uint16_t w=BSP_LCD_GetXSize(), h=BSP_LCD_GetYSize();

  BSP_LCD_Init(); // initialiser l'écran
  BSP_LCD_LayerDefaultInit(0, LCD_FB_START_ADDRESS);
  BSP_LCD_DisplayOn();
  BSP_LCD_SelectLayer(0);
  BSP_TS_Init(w, h);

  srand((unsigned)HAL_GetTick());

  osMutexDef(myMutex01); // initialiser le mutex et le créer
  myMutex01Handle = osMutexCreate(osMutex(myMutex01));

  osThreadDef(displayTask, function_display_task, osPriorityNormal, 0, 512); // tâche d'affichage
  task_displayHandle = osThreadCreate(osThread(displayTask), NULL);

  osThreadDef(moveTask, function_move, osPriorityAboveNormal, 0, 512); // tâche du jeu
  task_moveHandle   = osThreadCreate(osThread(moveTask), NULL);
}

/* -------------------------------------------------------------------------- */
/*                              DISPLAY TASK                                  */
/* -------------------------------------------------------------------------- */
void function_display_task(void const * argument)
{
  uint16_t w=BSP_LCD_GetXSize(), h=BSP_LCD_GetYSize();
  uint16_t sq=(w<h?w:h)/COLS;
  uint16_t ox=(w-sq*COLS)/2, oy=(h-sq*ROWS)/2;

  for(;;)
  {
    osMutexWait(myMutex01Handle, portMAX_DELAY);
    BSP_LCD_Clear(LCD_COLOR_BLACK);
    BSP_LCD_SetBackColor(LCD_COLOR_BLACK);

    if(screenState==STATE_MENU) // on cérifie si on est sur l'écran d'acceuil
    {
      BSP_LCD_SetTextColor(LCD_COLOR_CYAN);
      BSP_LCD_SetFont(&Font24);
      BSP_LCD_DisplayStringAt(0, h/4, (uint8_t*)"Jeu de Dames", CENTER_MODE);

      BSP_LCD_SetFont(&Font16);
      BSP_LCD_SetTextColor(LCD_COLOR_GREEN);
      BSP_LCD_DrawRect(BTN_X, BTN_Y, BTN_W, BTN_H);
      BSP_LCD_DisplayStringAt(0, BTN_Y+(BTN_H-16)/2,
                              (uint8_t*)"Classique", CENTER_MODE); // mode classique

      BSP_LCD_SetTextColor(LCD_COLOR_MAGENTA);
      BSP_LCD_DrawRect(BTN_X, BTN2_Y, BTN_W, BTN_H);
      BSP_LCD_DisplayStringAt(0, BTN2_Y+(BTN_H-16)/2,
                              (uint8_t*)"Contre l'ordi", CENTER_MODE); // mode contre l'ordinateur
    }
    else
    {
      /* plateau + pions + sélection */
      for(uint16_t i=0;i<ROWS;i++)
        for(uint16_t j=0;j<COLS;j++)
        {
          BSP_LCD_SetTextColor(((i+j)&1)?LCD_COLOR_BLACK:LCD_COLOR_WHITE);
          BSP_LCD_FillRect(ox+j*sq, oy+i*sq, sq, sq);
          uint8_t p=board[i][j];
          if(p)
          {
            uint32_t col=(owner(p)==1)?LCD_COLOR_RED:LCD_COLOR_GREEN;
            BSP_LCD_SetTextColor(col);
            BSP_LCD_FillCircle(ox+j*sq+sq/2, oy+i*sq+sq/2, sq/2-4);
            if(p==P1_KING||p==P2_KING)
            {
              BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
              BSP_LCD_DrawCircle(ox+j*sq+sq/2, oy+i*sq+sq/2, sq/2-8);
            }
          }
        }
      if(selected)
      {
        BSP_LCD_SetTextColor(LCD_COLOR_MAGENTA);
        BSP_LCD_DrawRect(ox+selC*sq, oy+selR*sq, sq, sq);
        BSP_LCD_DrawRect(ox+selC*sq+2, oy+selR*sq+2, sq-4, sq-4);
      }

      /* Affichage de l'état de la partie */
      if(gameOver)
      {
        BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
        BSP_LCD_SetFont(&Font16);
        BSP_LCD_DisplayStringAt(0, 10,
                               (uint8_t*)(winner == 1 ? "ROUGE GAGNE!" : "VERT GAGNE!"),
                               CENTER_MODE);
      }
      else
      {
        BSP_LCD_SetTextColor(currentPlayer == 1 ? LCD_COLOR_RED : LCD_COLOR_GREEN);
        BSP_LCD_SetFont(&Font12);
        uint16_t scrW = BSP_LCD_GetXSize();
        uint16_t marginY = 4;

        BSP_LCD_SetTextColor(currentPlayer == 1 ? LCD_COLOR_RED : LCD_COLOR_GREEN);
        BSP_LCD_SetFont(&Font12);

        BSP_LCD_DisplayStringAt(scrW - 1, marginY,(uint8_t*)(currentPlayer == 1 ? "Tour: ROUGE": "Tour: VERT"),RIGHT_MODE);
      }

      /* message "CPU envoie…" */
      if(cpuMode==1 && currentPlayer==2)
      {
        BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
        BSP_LCD_SetFont(&Font12);
        BSP_LCD_DisplayStringAt(0, h-20,
           (uint8_t*)"CPU envoi caracteres...", CENTER_MODE);
      }
    }
    osMutexRelease(myMutex01Handle);
    vTaskSuspend(NULL);
  }
}

/* -------------------------------------------------------------------------- */
/*                               MOVE TASK                                    */
/* -------------------------------------------------------------------------- */
void function_move(void const * argument)
{
  TS_StateTypeDef ts;
  uint16_t w=BSP_LCD_GetXSize(), h=BSP_LCD_GetYSize();
  uint16_t sq=(w<h?w:h)/COLS;
  uint16_t ox=(w-sq*COLS)/2, oy=(h-sq*ROWS)/2;

  vTaskDelay(100);
  vTaskResume(task_displayHandle);

  for(;;)
  {
    /* ---------------------- CPU : envoi UART ---------------------------- */
    if (screenState == STATE_GAME && cpuMode == 1 && currentPlayer == 2 && !gameOver)
    {
        // Étape 1 : envoyer le plateau complet
        HAL_UART_Transmit(&huart1, (uint8_t*)board, sizeof(board), HAL_MAX_DELAY);
        vTaskDelay(100);  // laisser le temps au PC de traiter

        // Étape 2 : recevoir le plateau case par case
        HAL_UART_AbortReceive_IT(&huart1);  // éviter conflit IT
        uint8_t new_board[ROWS * COLS] = {0};
        uint16_t received = 0;

        while (received < ROWS * COLS)
        {
            uint8_t val = 0;
            if (HAL_UART_Receive(&huart1, &val, 1, 1000) == HAL_OK)
            {
                new_board[received++] = val;

                // accusé de réception
                uint8_t ack = 'r';
                HAL_UART_Transmit(&huart1, &ack, 1, HAL_MAX_DELAY);
            }
            else
            {
                break;  // timeout ou erreur
            }
        }

        if (received == ROWS * COLS)
        {
            osMutexWait(myMutex01Handle, portMAX_DELAY);

            for (uint16_t i = 0; i < ROWS; i++)
                for (uint16_t j = 0; j < COLS; j++)
                    board[i][j] = new_board[i * COLS + j];

            currentPlayer = 1;
            check_victory(); // Vérifier après mise à jour du plateau

            BSP_LCD_SetTextColor(LCD_COLOR_CYAN);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
            BSP_LCD_DisplayStringAt(0, h - 35, (uint8_t*)"Plateau mis a jour", CENTER_MODE);

            osMutexRelease(myMutex01Handle);
            vTaskResume(task_displayHandle);
        }
        else
        {
            osMutexWait(myMutex01Handle, portMAX_DELAY);
            BSP_LCD_SetTextColor(LCD_COLOR_RED);
            BSP_LCD_SetFont(&Font12);
            BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
            BSP_LCD_DisplayStringAt(0, h - 35, (uint8_t*)"Reception incomplete", CENTER_MODE);
            osMutexRelease(myMutex01Handle);
            vTaskResume(task_displayHandle);
        }
    }

    /* ------------------- Gestion du tactile ------------------ */
    BSP_TS_GetState(&ts);
    if(ts.touchDetected)
    {
      vTaskDelay(50); BSP_TS_GetState(&ts);
      if(!ts.touchDetected) { vTaskDelay(10); continue; }

      uint16_t x=ts.touchX[0], y=ts.touchY[0];

      /* ---------------- Menu : choix mode ------------------------------- */
      if(screenState==STATE_MENU)
      {
        if(x>=BTN_X && x<BTN_X+BTN_W && y>=BTN_Y && y<BTN_Y+BTN_H)
          cpuMode = 0;
        else if(x>=BTN_X && x<BTN_X+BTN_W && y>=BTN2_Y && y<BTN2_Y+BTN_H)
          cpuMode = 1;
        else { vTaskDelay(10); continue; }

        osMutexWait(myMutex01Handle, portMAX_DELAY);
        for(uint16_t i=0;i<ROWS;i++)
          for(uint16_t j=0;j<COLS;j++) board[i][j]=0;


        for (uint16_t i = 0; i < 4; i++) {
          for (uint16_t j = 0; j < COLS; j++) {
            if ((i+j) % 2 == 1) {
              board[i][j] = P2_PAWN;
            }
          }
        }

        for (uint16_t i = ROWS-4; i < ROWS; i++) {
          for (uint16_t j = 0; j < COLS; j++) {
            if ((i+j) % 2 == 1) {
              board[i][j] = P1_PAWN;
            }
          }
        }

        selected=0; currentPlayer=1; gameOver=0; winner=0;
        screenState=STATE_GAME;
        osMutexRelease(myMutex01Handle);
        vTaskResume(task_displayHandle);
      }
      /* --------------- Jeu : sélection / déplacement -------------------- */
      else if(!gameOver) // Ne permettre le jeu que si la partie n'est pas terminée
      {
        if(x<ox||y<oy) { vTaskDelay(10); continue; }
        uint16_t col=(x-ox)/sq, row=(y-oy)/sq;
        if(row>=ROWS||col>=COLS) { vTaskDelay(10); continue; }

        osMutexWait(myMutex01Handle, portMAX_DELAY);
        uint8_t p=board[row][col];

        if(!selected &&
          ((currentPlayer==1&&(p==P1_PAWN||p==P1_KING))||
           (currentPlayer==2&&cpuMode==0&&(p==P2_PAWN||p==P2_KING))))
        {
          selected=1; selR=row; selC=col;
        }
        else if(selected)
        {
          uint8_t src=board[selR][selC];
          uint8_t moved=0;

          /* --- déplacement / capture validés ------------------------------------ */
          uint8_t capture_done     = 0;   /* 1 si une prise vient d'être faite   */
          uint8_t keep_selection   = 0;   /* 1 si d'autres prises sont possibles */

          if ((src==P1_PAWN||src==P2_PAWN) && is_valid_move(selR,selC,row,col))
          {
              board[row][col]      = src;
              board[selR][selC]    = 0;
              try_promote(row,col);
              moved                = 1;
          }
          else if ((src==P1_KING||src==P2_KING) &&
                   is_valid_move_king(selR,selC,row,col))
          {
              board[row][col]      = src;
              board[selR][selC]    = 0;
              moved                = 1;
          }
          else if ((src==P1_PAWN||src==P2_PAWN) &&
                   is_capture_move(selR,selC,row,col))
          {
              uint16_t mR = (selR + row) / 2, mC = (selC + col) / 2;
              board[row][col]      = src;
              board[selR][selC]    = 0;
              board[mR][mC]        = 0;
              try_promote(row,col);
              capture_done         = 1;
              moved                = 1;
          }
          else if ((src==P1_KING||src==P2_KING) &&
                   is_capture_move_king(selR,selC,row,col))
          {
              int dr = (row > selR) ? 1 : -1;
              int dc = (col > selC) ? 1 : -1;
              for (uint16_t r = selR + dr, c = selC + dc; r != row; r += dr, c += dc)
                  if (board[r][c]) { board[r][c] = 0; break; }
              board[row][col]      = src;
              board[selR][selC]    = 0;
              capture_done         = 1;
              moved                = 1;
          }

          /* --- après déplacement -------------------------------------------------- */
          if (capture_done && has_additional_capture(row, col))
          {
              /* on reste sur la même pièce : autre prise possible */
              selected   = 1;
              selR       = row;
              selC       = col;
              keep_selection = 1;
          }
          else if (moved)
          {
              selected   = 0;
              if (!keep_selection) {
                  /* changement de joueur uniquement si plus de capture enchaînable */
                  currentPlayer = 3 - currentPlayer;
              }
          }
          else
          {
              selected = 0; // Désélectionner si mouvement invalide
          }

          // Vérifier la victoire après chaque mouvement valide
          if (moved) {
              check_victory();
          }
        }
        else
        {
          selected = 0; // Désélectionner si clic sur une case vide
        }

        osMutexRelease(myMutex01Handle);
        vTaskResume(task_displayHandle);
      }
    }

    vTaskDelay(10);
  }
}
